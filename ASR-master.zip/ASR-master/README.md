# ASR
- ASR using Deepspeech.
- Deployement on server.


#### Deepspeech Model 0.6.0 version
 
```
wget https://github.com/mozilla/DeepSpeech/releases/download/v0.6.1/deepspeech-0.6.1-models.tar.gz
tar xvfz deepspeech-0.6.1-models.tar.gz

```
