# stt with pronounciation score using pocketsniphics
